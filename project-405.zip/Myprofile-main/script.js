// script.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Welcome to the Car Rental Company!');
});

